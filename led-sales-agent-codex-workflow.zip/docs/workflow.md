# Codex Development Workflow

## One-task execution loop

1. Read project files:
   - AGENTS.md
   - PLANS.md
   - TASKS.md
   - CONTEXT.md
   - DECISIONS.md

2. Pick one READY task.

3. Restate:
   - task ID
   - goal
   - scope
   - acceptance criteria
   - affected files

4. Implement minimal changes.

5. Add/update tests.

6. Run checks.

7. Self-review diff.

8. Fix issues.

9. Update TASKS.md and CONTEXT.md.

10. Stop.

## Recommended first Codex prompt

```text
Read AGENTS.md, PLANS.md, TASKS.md, CONTEXT.md, and DECISIONS.md.
Work on TASK-001 only.

Before coding:
- restate the goal
- list constraints
- list acceptance criteria
- identify likely affected files

Then implement the task, run relevant checks, self-review the diff, update TASKS.md and CONTEXT.md, and stop.
```

## Recommended review prompt

```text
Review the current diff against AGENTS.md, TASKS.md, and the acceptance criteria.
Focus on scope creep, missing tests, broken architecture boundaries, security risks, and missing context updates.
Do not edit files. Return findings by severity.
```

## Recommended security review prompt

```text
Review this task for security risks:
- secrets
- OAuth tokens
- Telegram authorization
- approval bypass
- customer data
- external API calls
Return findings by severity with file references.
```
