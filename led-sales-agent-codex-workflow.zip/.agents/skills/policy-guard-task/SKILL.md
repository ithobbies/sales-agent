---
name: policy-guard-task
description: Use this skill when validating customer replies, listing drafts, pricing, discounts, product claims, and OLX-risky actions.
---

# Policy Guard Task Skill

## Must detect

- exact powerbank runtime claims without data
- full waterproof/submersion claims
- unsupported warranty/certification claims
- price below configured minimum
- discounts not allowed by rules
- duplicate or near-duplicate listing drafts
- external links when not allowed
- customer bank card requests
- aggressive or misleading sales claims

## Output

Policy Guard must return structured result:

- `allowed`: boolean
- `risk_level`: low/medium/high/blocker
- `violations`: list
- `required_changes`: list
- `requires_human_approval`: boolean

## Examples to block

- “Будет светить 12 часов от любого павербанка”
- “Полностью водонепроницаемая, можно погружать”
- “Скину до 150 грн”
- “Отправьте номер карты”
