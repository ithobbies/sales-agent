---
name: testing-and-repair-loop
description: Use this skill when implementing code that requires checks, fixing failing tests, or validating before task completion.
---

# Testing and Repair Loop Skill

## Workflow

1. Identify task ID and acceptance criteria.
2. Determine smallest relevant test scope.
3. Run relevant tests/checks.
4. If failures occur:
   - read failure carefully
   - identify root cause
   - apply smallest related fix
   - rerun relevant tests
5. Repeat until pass or blocker is documented.
6. Run broader checks if shared code changed.
7. Do not mark task done without verification or documented blocker.

## Commands

```bash
cd backend
python manage.py check
python manage.py makemigrations --check --dry-run
python manage.py test
```

Optional:

```bash
pytest
ruff check .
ruff format --check .
mypy .
```
